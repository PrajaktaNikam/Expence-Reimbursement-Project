package com.expence.reimbursement.expence.reimbursement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpenceReimbursementApplicationTests {

	@Test
	void contextLoads() {
	}

}
