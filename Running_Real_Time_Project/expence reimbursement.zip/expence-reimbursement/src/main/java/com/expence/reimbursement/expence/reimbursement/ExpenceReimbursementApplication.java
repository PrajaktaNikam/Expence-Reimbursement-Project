package com.expence.reimbursement.expence.reimbursement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExpenceReimbursementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExpenceReimbursementApplication.class, args);
	}

}
